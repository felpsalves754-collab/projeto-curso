# DevLinks — Projeto Final

Projeto final inspirado no layout DevLinks/Discover da Rocketseat.

## Tecnologias
- HTML
- CSS
- JavaScript

## Como executar
1. Baixe/clique em `index.html`.
2. Abra no navegador.

## Personalização
No `index.html`, altere:
- `@felps`
- descrição
- URLs dos quatro botões
- URLs dos ícones sociais

O botão no canto superior alterna entre tema claro e escuro e salva a preferência no navegador.
